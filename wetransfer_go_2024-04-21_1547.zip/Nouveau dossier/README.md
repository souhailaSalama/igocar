

## Getting Started
requirements:
- nodejs : https://nodejs.org/en/download
-.env file need to be in root of project

NB: .env file has all envirement to run project 

how to install run this command in the root of project:
-npm install

to run the server :
-npm run dev
