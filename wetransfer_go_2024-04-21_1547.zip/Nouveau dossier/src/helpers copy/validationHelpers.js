export const antdFieldValidation = [
  {
    required: true,
    message: "Required",
  },
];
